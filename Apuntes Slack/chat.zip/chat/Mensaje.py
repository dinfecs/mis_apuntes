class Mensaje(object):

    def __init__(self, alias, mensaje):
        self.alias = alias
        self.mensaje = mensaje
