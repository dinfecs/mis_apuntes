class Mensaje(object):

    def __init__(self, alias, text):
        self.alias = alias
        self.text = text
