from models import db
db.create_all()