from flask import Flask, render_template
from models import db, Experiencia
app = Flask(__name__)
app.secret_key = 'secret'


@app.route("/")
def index():
    my_experiencia = Experiencia.query.order_by(Experiencia.anyo_salida)
    return render_template('items/curriculum_vitae.html', experiencia=my_experiencia)

if __name__ == "__main__":
    app.debug = True
    app.run()