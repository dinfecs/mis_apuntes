from flask import Flask, render_template, redirect, url_for, request, flash
from forms import NewForm
from DB import Note, db

app = Flask(__name__)
app.secret_key = 'secret'

@app.route("/")
def index():
    return redirect(url_for('new_note'))

@app.route("/new", methods=['GET', 'POST'])
def new_note():
    form = NewForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            # Guardamos en la base de datos
            flash('Guardado bien', 'success')
            my_note = Note(request.form['title'], request.form['text'])
            db.session.add(my_note)
            db.session.commit()
        else:
            # Mostramos errores
            errores = form.errors.items()
            for campo, mensajes in errores:
                for mensaje in mensajes:
                    flash(mensaje, 'danger')
    return render_template('items/new.html', form=form)


if __name__ == "__main__":
    app.debug = True
    app.run()