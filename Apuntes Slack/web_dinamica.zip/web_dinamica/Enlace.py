class Enlace(object):

    def __init__(self, enlace, text):
        self.enlace = enlace
        self.text = text