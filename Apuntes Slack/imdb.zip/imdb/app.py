from flask import Flask, redirect, url_for, render_template, request, flash
from forms import User_form
from models import User
app = Flask(__name__)
app.secret_key = 'secret'


@app.route("/")
def index():
    return redirect(url_for('signup'))


@app.route("/signup", methods=['GET', 'POST'])
def signup():
    form = User_form()
    if request.method == 'POST':
        email = request.form['email']
        my_user = User.query.filter_by(email=email).first()
        if not my_user:
            if request.form['password1'] == request.form['password2']:
                flash('Good', 'success')
            else:
                flash('Los passwords no son iguales', 'danger')
        else:
            flash('El e-mail ya esta registrado', 'danger')
    return render_template('items/signup.html', form=form)


if __name__ == "__main__":
    app.debug = True
    app.run()