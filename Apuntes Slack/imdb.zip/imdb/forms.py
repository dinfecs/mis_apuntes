from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class User_form(FlaskForm):
    username = StringField('Nombre', validators=[DataRequired('Debe introducir su nombre'), Length(1, 100, 'Su nombre no debe superar los 100 carácteres')])
    email = StringField('E-mail', validators=[DataRequired('Debe introducir su correo electrónico'), Email('El formato de su correo electrónico no es válido.'), Length(1, 80, 'Su e-mail es demasiado largo.')])
    password1 = PasswordField('Password', validators=[DataRequired('Debe introducir su contraseña')])
    password2 = PasswordField('Repita su contraseña', validators=[DataRequired('Debe introducir su contraseña de nuevo')])

    submit = SubmitField('Registrarme')
